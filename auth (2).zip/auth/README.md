# Auth Service

A Spring Boot microservice for authentication using OTP (One-Time Password) functionality via MessageCentral API.

## Features

- Send OTP to mobile numbers
- Validate OTP codes
- Integration with MessageCentral verification API
- RESTful API endpoints

## Technology Stack

- Java 11
- Spring Boot 2.7.14
- Maven
- Lombok
- Jackson

## Project Structure

```
auth/
├── src/
│   ├── main/
│   │   ├── java/
│   │   │   └── com/
│   │   │       └── truly/
│   │   │           └── app/
│   │   │               └── auth/
│   │   │                   ├── AuthServiceApplication.java
│   │   │                   ├── client/
│   │   │                   │   └── MessageCentralClient.java
│   │   │                   ├── config/
│   │   │                   │   └── RestTemplateConfig.java
│   │   │                   ├── controller/
│   │   │                   │   └── AuthController.java
│   │   │                   ├── enums/
│   │   │                   │   └── MessageCentralCode.java
│   │   │                   ├── request/
│   │   │                   │   ├── SendOtpRequest.java
│   │   │                   │   └── ValidateOtpRequest.java
│   │   │                   ├── response/
│   │   │                   │   ├── SendOtpResponse.java
│   │   │                   │   └── ValidateOtpResponse.java
│   │   │                   └── util/
│   │   │                       └── MessageCentralErrorParser.java
│   │   └── resources/
│   │       └── application.yml
│   └── test/
│       └── java/
└── pom.xml
```

## Configuration

Configure the MessageCentral API credentials in `application.yml` or via environment variables:

```yaml
messagecentral:
  base-url: ${MESSAGECENTRAL_BASE_URL:https://api.messagecentral.com}
  auth-token: ${MESSAGECENTRAL_AUTH_TOKEN:your-auth-token-here}
```

## API Endpoints

### Send OTP

**POST** `/api/auth/send-otp`

Request body:
```json
{
  "countryCode": "91",
  "mobileNumber": "9876543210"
}
```

### Validate OTP

**POST** `/api/auth/validate-otp`

Request body:
```json
{
  "verificationId": "verification-id-from-send-otp",
  "code": "123456"
}
```

## Building and Running

### Build the project

```bash
cd auth
mvn clean install
```

### Run the application

```bash
mvn spring-boot:run
```

Or run the JAR:

```bash
java -jar target/auth-service-1.0.0.jar
```

The service will start on port 8081 by default.

## Environment Variables

- `MESSAGECENTRAL_BASE_URL`: Base URL for MessageCentral API
- `MESSAGECENTRAL_AUTH_TOKEN`: Authentication token for MessageCentral API

## Error Handling

The service handles various MessageCentral error codes:
- `2018`: Request already exists
- `2019`: Maximum limit reached
- `2020`: Invalid country code
- `2021`: Duplicate resource
- `2022`: Invalid customer ID
- `400`: Bad request
- `500`: Server error
