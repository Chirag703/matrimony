package com.truly.app.auth.client;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import com.truly.app.auth.enums.MessageCentralCode;
import com.truly.app.auth.exception.OtpSendFailedException;
import com.truly.app.auth.exception.OtpValidationFailedException;
import com.truly.app.auth.request.SendOtpRequest;
import com.truly.app.auth.request.ValidateOtpRequest;
import com.truly.app.auth.response.SendOtpResponse;
import com.truly.app.auth.response.ValidateOtpResponse;
import com.truly.app.auth.util.MessageCentralErrorParser;

@Component
public class MessageCentralClient {

	private static final Logger log = LoggerFactory.getLogger(MessageCentralClient.class);

	@Value("${messagecentral.base-url}")
	private String baseUrl;

	@Value("${messagecentral.auth-token}")
	private String authToken;

	private final RestTemplate restTemplate;

	public MessageCentralClient(RestTemplate restTemplate) {
		this.restTemplate = restTemplate;
	}

	private HttpHeaders headers() {
		HttpHeaders headers = new HttpHeaders();
		headers.set("authToken", authToken);
		headers.setContentType(MediaType.APPLICATION_JSON);
		return headers;
	}

	/* ========================= SEND OTP ========================= */

	public SendOtpResponse sendOtp(SendOtpRequest request) {

		String url = baseUrl + "/verification/v3/send" + "?countryCode=" + request.getCountryCode() + "&flowType=SMS"
				+ "&mobileNumber=" + request.getMobileNumber();

		log.info("Send OTP URL={}", url);

		try {
			ResponseEntity<SendOtpResponse> response = restTemplate.exchange(url, HttpMethod.POST,
					new HttpEntity<>(headers()), SendOtpResponse.class);

			return response.getBody();

		} catch (HttpClientErrorException ex) {

			String body = ex.getResponseBodyAsString();
			log.error("Send OTP error={}", body);

			SendOtpResponse errorResponse = MessageCentralErrorParser.parse(body, SendOtpResponse.class);

			MessageCentralCode code = MessageCentralCode.fromCode(String.valueOf(errorResponse.getResponseCode()));

			switch (code) {
				case REQUEST_ALREADY_EXISTS:
				case MAXIMUM_LIMIT_REACHED:
				case INVALID_COUNTRY_CODE:
				case DUPLICATE_RESOURCE:
				case BAD_REQUEST:
				case INVALID_CUSTOMER_ID:
					return errorResponse;

				case SERVER_ERROR:
				default:
					throw new OtpSendFailedException("OTP_SEND_FAILED: " + code.name(), code.getCode());
			}
		}
	}

	/* ========================= VALIDATE OTP ========================= */

	public ValidateOtpResponse validateOtp(ValidateOtpRequest request) {

		String url = baseUrl + "/verification/v3/validateOtp" + "?verificationId=" + request.getVerificationId()
				+ "&code=" + request.getCode();

		log.info("Validate OTP URL={}", url);

		try {
			ResponseEntity<ValidateOtpResponse> response = restTemplate.exchange(url, HttpMethod.GET,
					new HttpEntity<>(headers()), ValidateOtpResponse.class);

			ValidateOtpResponse responseBody = response.getBody();

			// Extract phone number from the data map if available
			if (responseBody != null && responseBody.getData() != null) {
				responseBody.setPhoneNumber(responseBody.getData().getMobileNumber());
			}

			return responseBody;

		} catch (HttpClientErrorException ex) {

			String body = ex.getResponseBodyAsString();
			log.error("Validate OTP error={}", body);

			ValidateOtpResponse errorResponse = MessageCentralErrorParser.parse(body, ValidateOtpResponse.class);

			MessageCentralCode code = MessageCentralCode.fromCode(String.valueOf(errorResponse.getResponseCode()));

			switch (code) {
				case REQUEST_ALREADY_EXISTS:
				case MAXIMUM_LIMIT_REACHED:
				case INVALID_COUNTRY_CODE:
				case DUPLICATE_RESOURCE:
				case BAD_REQUEST:
				case INVALID_CUSTOMER_ID:
				case INVALID_VERIFICATION_ID:
				case VERIFICATION_FAILED:
				case WRONG_OTP_PROVIDED:
				case ALREADY_VERIFIED:
				case VERIFICATION_EXPIRED:
					return errorResponse;

				case SERVER_ERROR:
				default:
					throw new OtpValidationFailedException("OTP_VALIDATION_FAILED: " + code.name(), code.getCode());
			}
		}
	}
}
