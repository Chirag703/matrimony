package com.truly.app.auth.request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SendOtpRequest {
    
    @NotBlank(message = "Country code is required")
    private String countryCode;
    
    @NotBlank(message = "Mobile number is required")
    private String mobileNumber;
}
