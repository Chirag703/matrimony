package com.truly.app.auth.request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ValidateOtpRequest {
    
    @NotBlank(message = "Verification ID is required")
    private String verificationId;
    
    @NotBlank(message = "OTP code is required")
    private String code;
}
