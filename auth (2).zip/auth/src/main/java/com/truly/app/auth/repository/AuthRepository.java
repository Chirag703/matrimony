package com.truly.app.auth.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.truly.app.auth.entity.Auth;

@Repository
public interface AuthRepository extends JpaRepository<Auth, Long> {
    boolean existsByPhoneNumber(String phoneNumber);
}
