package com.truly.app.auth.controller;

import com.truly.app.auth.client.MessageCentralClient;
import com.truly.app.auth.entity.Auth;
import com.truly.app.auth.repository.AuthRepository;
import com.truly.app.auth.request.SendOtpRequest;
import com.truly.app.auth.request.ValidateOtpRequest;
import com.truly.app.auth.response.SendOtpResponse;
import com.truly.app.auth.response.ValidateOtpResponse;
import com.truly.app.auth.util.JwtUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@RestController
@RequestMapping("/api/auth")
@CrossOrigin(origins = "*")
public class AuthController {

    private static final Logger log = LoggerFactory.getLogger(AuthController.class);

    private final MessageCentralClient messageCentralClient;
    private final JwtUtil jwtUtil;
    private final AuthRepository authRepository;

    public AuthController(MessageCentralClient messageCentralClient, JwtUtil jwtUtil, AuthRepository authRepository) {
        this.messageCentralClient = messageCentralClient;
        this.jwtUtil = jwtUtil;
        this.authRepository = authRepository;
    }

    @PostMapping("/send-otp")
    public ResponseEntity<SendOtpResponse> sendOtp(@Valid @RequestBody SendOtpRequest request) {
        String mobileNumber = request.getMobileNumber();

        if (!authRepository.existsByPhoneNumber(mobileNumber)) {
            Auth auth = Auth.builder()
                    .phoneNumber(mobileNumber)
                    .latitude(null)
                    .longitude(null)
                    .build();
            auth.setCreatedAt(java.time.LocalDateTime.now());
            authRepository.save(auth);
        }

        log.info("Received send OTP request for mobile: {}", mobileNumber);
        SendOtpResponse response = messageCentralClient.sendOtp(request);
        return ResponseEntity.ok(response);
    }

    @PostMapping("/validate-otp")
    public ResponseEntity<ValidateOtpResponse> validateOtp(@Valid @RequestBody ValidateOtpRequest request) {
        log.info("Received validate OTP request for verificationId: {}", request.getVerificationId());
        ValidateOtpResponse response = messageCentralClient.validateOtp(request);

        if (isOtpVerified(response)) {
            String phone = resolvePhoneNumber(response);
            if (phone != null && !phone.isBlank()) {
                response.setPhoneNumber(phone);
                response.setToken(jwtUtil.generateToken(phone));
            } else {
                log.warn("OTP verified but phone number missing in response payload");
            }
        }
        return ResponseEntity.ok(response);
    }

    private boolean isOtpVerified(ValidateOtpResponse response) {
        if (response == null || response.getResponseCode() == null || response.getResponseCode() != 200) {
            return false;
        }

        if (response.getData() == null) {
            return true; // treat success code as verified when data is missing
        }

        String status = response.getData().getVerificationStatus();
        if (status == null || status.isBlank()) {
            return true;
        }

        return "VERIFIED".equalsIgnoreCase(status)
                || "VERIFICATION_SUCCESS".equalsIgnoreCase(status)
                || "VERIFICATION_COMPLETED".equalsIgnoreCase(status)
                || "SUCCESS".equalsIgnoreCase(status);
    }

    private String resolvePhoneNumber(ValidateOtpResponse response) {
        if (response.getPhoneNumber() != null && !response.getPhoneNumber().isBlank()) {
            return response.getPhoneNumber();
        }
        if (response.getData() != null) {
            return response.getData().getMobileNumber();
        }
        return "";
    }
}
