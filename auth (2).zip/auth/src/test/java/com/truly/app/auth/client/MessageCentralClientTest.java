package com.truly.app.auth.client;

import com.truly.app.auth.enums.MessageCentralCode;
import com.truly.app.auth.exception.OtpSendFailedException;
import com.truly.app.auth.exception.OtpValidationFailedException;
import com.truly.app.auth.request.SendOtpRequest;
import com.truly.app.auth.request.ValidateOtpRequest;
import com.truly.app.auth.response.SendOtpResponse;
import com.truly.app.auth.response.ValidateOtpResponse;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.http.*;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

class MessageCentralClientTest {

    private MessageCentralClient messageCentralClient;
    private RestTemplate restTemplate;

    @BeforeEach
    void setUp() {
        restTemplate = mock(RestTemplate.class);
        messageCentralClient = new MessageCentralClient(restTemplate);
        
        // Use reflection to set the private fields for testing
        try {
            var baseUrlField = MessageCentralClient.class.getDeclaredField("baseUrl");
            baseUrlField.setAccessible(true);
            baseUrlField.set(messageCentralClient, "https://api.messagecentral.com");
            
            var authTokenField = MessageCentralClient.class.getDeclaredField("authToken");
            authTokenField.setAccessible(true);
            authTokenField.set(messageCentralClient, "test-token");
        } catch (Exception e) {
            fail("Failed to set up test: " + e.getMessage());
        }
    }

    @Test
    void testSendOtp_Success() {
        // Arrange
        SendOtpRequest request = SendOtpRequest.builder()
                .countryCode("91")
                .mobileNumber("9876543210")
                .build();

        SendOtpResponse expectedResponse = SendOtpResponse.builder()
                .responseCode(200)
                .message("Success")
                .build();

        when(restTemplate.exchange(
                anyString(),
                eq(HttpMethod.POST),
                any(HttpEntity.class),
                eq(SendOtpResponse.class)
        )).thenReturn(ResponseEntity.ok(expectedResponse));

        // Act
        SendOtpResponse response = messageCentralClient.sendOtp(request);

        // Assert
        assertNotNull(response);
        assertEquals(200, response.getResponseCode());
        assertEquals("Success", response.getMessage());
        verify(restTemplate, times(1)).exchange(
                anyString(),
                eq(HttpMethod.POST),
                any(HttpEntity.class),
                eq(SendOtpResponse.class)
        );
    }

    @Test
    void testSendOtp_Failure_ThrowsException() {
        // Arrange
        SendOtpRequest request = SendOtpRequest.builder()
                .countryCode("91")
                .mobileNumber("9876543210")
                .build();

        String errorBody = "{\"responseCode\":500,\"message\":\"Server Error\"}";
        
        when(restTemplate.exchange(
                anyString(),
                eq(HttpMethod.POST),
                any(HttpEntity.class),
                eq(SendOtpResponse.class)
        )).thenThrow(new HttpClientErrorException(HttpStatus.INTERNAL_SERVER_ERROR, "Server Error", errorBody.getBytes(), null));

        // Act & Assert
        assertThrows(OtpSendFailedException.class, () -> messageCentralClient.sendOtp(request));
    }

    @Test
    void testValidateOtp_Success() {
        // Arrange
        ValidateOtpRequest request = ValidateOtpRequest.builder()
                .verificationId("test-verification-id")
                .code("123456")
                .build();

        ValidateOtpResponse.ValidateOtpData data = new ValidateOtpResponse.ValidateOtpData();
        data.setMobileNumber("9876543210");
        data.setVerificationStatus("VERIFIED");

        ValidateOtpResponse expectedResponse = ValidateOtpResponse.builder()
                .responseCode(200)
                .message("Success")
                .data(data)
                .build();

        when(restTemplate.exchange(
                anyString(),
                eq(HttpMethod.GET),
                any(HttpEntity.class),
                eq(ValidateOtpResponse.class)
        )).thenReturn(ResponseEntity.ok(expectedResponse));

        // Act
        ValidateOtpResponse response = messageCentralClient.validateOtp(request);

        // Assert
        assertNotNull(response);
        assertEquals(200, response.getResponseCode());
        assertEquals("Success", response.getMessage());
        assertEquals("9876543210", response.getPhoneNumber());
        verify(restTemplate, times(1)).exchange(
                anyString(),
                eq(HttpMethod.GET),
                any(HttpEntity.class),
                eq(ValidateOtpResponse.class)
        );
    }

    @Test
    void testMessageCentralCode_FromCode() {
        // Test known codes
        assertEquals(MessageCentralCode.REQUEST_ALREADY_EXISTS, MessageCentralCode.fromCode("2018"));
        assertEquals(MessageCentralCode.MAXIMUM_LIMIT_REACHED, MessageCentralCode.fromCode("2019"));
        assertEquals(MessageCentralCode.INVALID_COUNTRY_CODE, MessageCentralCode.fromCode("2020"));
        assertEquals(MessageCentralCode.SERVER_ERROR, MessageCentralCode.fromCode("500"));
        assertEquals(MessageCentralCode.BAD_REQUEST, MessageCentralCode.fromCode("400"));
        
        // Test unknown code
        assertEquals(MessageCentralCode.UNKNOWN, MessageCentralCode.fromCode("9999"));
        assertEquals(MessageCentralCode.UNKNOWN, MessageCentralCode.fromCode(null));
    }
}
